# DefinitelyNotBot
A Discord bot coded in Discord.JS, hosted using Heroku.